/*###############################################
 CSE182 - Lab 3
 createindex.sql
 
###############################################*/

CREATE INDEX FindMembers
ON Members(name, address);